from dataclasses import dataclass


@dataclass
class Config:
    user: str
    database: str
    password: str
    host: str
    port: int
