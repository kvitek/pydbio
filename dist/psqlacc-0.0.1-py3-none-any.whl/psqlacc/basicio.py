import dataclasses
import re
from contextlib import contextmanager
from typing import (
    Any,
    Dict,
    Generator,
    Iterable,
    List,
    Sequence,
    Tuple,
    Union,
    cast,
)

import psycopg2
import psycopg2.sql
from psycopg2.extensions import connection as PSQLConnection

from .configtypes import Config


def open_psql_connection_native(
    host: str, port: int, database: str, user: str, passwd: str
) -> PSQLConnection:
    return psycopg2.connect(
        database=database, user=user, password=passwd, host=host, port=port
    )


class PSQL:
    def __init__(self, config: Config) -> None:
        self.config = dataclasses.replace(config)

    def _insternal_connect(self) -> PSQLConnection:
        return open_psql_connection_native(
            host=self.config.host,
            port=self.config.port,
            database=self.config.database,
            user=self.config.user,
            passwd=self.config.password,
        )

    @contextmanager
    def connect(self) -> Generator[PSQLConnection, None, None]:
        conn = self._insternal_connect()
        try:
            yield conn
        finally:
            try:
                conn.close()
            except Exception:
                pass

    def execute(
        self, query: str, params: Union[Dict[str, Any], Sequence[Any]] = ()
    ):
        with self.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(query, params)

            conn.commit()

    def executemany(self, query: str, data: Iterable[Any]):
        with self.connect() as conn:
            with conn.cursor() as cur:
                cur.executemany(query, data)

            conn.commit()

    def execute_in(
        self,
        query: str,
        params: Sequence[Any] = (),
        params_in: Sequence[Any] = (),
    ):
        query, params = parse_positional_command(query, params, params_in)

        self.execute(query, params)

    def fetch_tuples(
        self,
        query: str,
        params: Union[Dict[str, Any], Sequence[Any]] = (),
    ) -> List[Tuple[Any, ...]]:
        with self.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(query, params)
                return cast(List[Tuple[Any, ...]], cur.fetchall())

    def fetch_tuples_in(
        self,
        query: str,
        params: Sequence[Any] = (),
        params_in: Sequence[Any] = (),
    ) -> List[Tuple[Any, ...]]:
        query, params = parse_positional_command(query, params, params_in)

        return self.fetch_tuples(query, params)

    def fetch_dict(
        self,
        query: str,
        params: Union[Dict[str, Any], Sequence[Any]] = (),
    ) -> List[Dict[str, Any]]:
        with self.connect() as conn:
            with conn.cursor() as cur:
                cur.execute(query, params)
                data = cast(List[Tuple[Any, ...]], cur.fetchall())
                if cur.description is None:
                    raise Exception(
                        "fetch_dict can be used only with queries which return values"
                    )
                columns = [c[0] for c in cur.description]

        return [dict(zip(columns, row)) for row in data]

    def fetch_dict_in(
        self,
        query: str,
        params: Sequence[Any] = (),
        params_in: Sequence[Any] = (),
    ) -> List[Dict[str, Any]]:
        query, params = parse_positional_command(query, params, params_in)

        return self.fetch_dict(query, params)

    def database(self) -> str:
        return cast(str, self.fetch_tuples("select current_schema()")[0][0])


def parse_positional_command(
    query: str, params: Sequence[Any], params_in: Sequence[Any]
) -> Tuple[str, Sequence[Any]]:
    if "(__in__)" not in query:
        return query, params

    if len(params_in) == 0:
        return query, params

    part_one, _ = query.split("(__in__)")
    pos_args_in_one = len(re.findall(r"\%s", part_one, re.I))

    template = ", ".join("%s" for _ in range(len(params_in)))
    query = query.replace("__in__", template)

    return query, (
        list(params[:pos_args_in_one])
        + list(params_in)
        + list(params[pos_args_in_one:])
    )


__CONFIGS: dict[str, PSQL] = {}


def configure(configs: dict[str, Config]):
    for name, config in configs.items():
        __CONFIGS[name.lower()] = PSQL(config)


def get_connection(name: str) -> PSQL:
    p = __CONFIGS.get(name.lower())
    if p is None:
        raise KeyError(f"no config for name `{name}`")

    return p
